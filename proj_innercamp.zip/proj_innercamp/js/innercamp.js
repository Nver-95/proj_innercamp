const span = document.getElementById("span")
const list = document.getElementById("list")
list.style.display = "none";
span.addEventListener("click", (event) => {
    if (list.style.display == "none") {
        list.style.display = "block"
    }else {
        list.style.display = "none"
    }
})

const hamburger = document.getElementById('hamburger')
const navContent = document.getElementById('nav-content')
const navRight = document.getElementById('nav-right')

hamburger.addEventListener('click', () => {
    navContent.classList.toggle('show')
    navRight.classList.toggle('show')
})


